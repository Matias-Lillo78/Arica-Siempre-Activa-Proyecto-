from django.shortcuts import render, redirect, get_object_or_404
from .models import Restaurante
from .forms import RestauranteForm
from django.contrib import messages

# Create your views here.
def restauranteListView(request):
    return render(request, 'restaurantes/restaurante_lista.html', {'lista':Restaurante.objects.all()})

def restauranteCreateView(request):
    # Crea formulario
    form = RestauranteForm(request.POST or None, request.FILES or None) # FILES por trabajar con imagenes
    if request.method == "POST":
        if form.is_valid():
            form.save()
            messages.success(request, "Restaurante creado")
            return redirect('listar')  
    return render(request, 'restaurantes/restaurante_form.html', {'accion':'Crear', 'form':form})

def restauranteUpdateView(request, id):
    # buscar el elemento a actualizar
    restaurante = get_object_or_404(Restaurante, pk=id)
    # Crea formulario
    form = RestauranteForm(request.POST or None, request.FILES or None,  instance=restaurante) # FILES por trabajar con imagenes
    if request.method == "POST":
        if form.is_valid():
            form.save()
            messages.success(request, "Restaurante actualizado")
            return redirect('listar')  
    return render(request, 'restaurantes/restaurante_form.html', {'accion':'Actualizar', 'form':form})

def restauranteDetailView(request, id):
    restaurante = get_object_or_404(Restaurante, pk=id)
    return render(request, 'restaurantes/restaurante_detalle.html', {'restaurante':restaurante})