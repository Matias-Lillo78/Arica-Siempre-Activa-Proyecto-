from django.db import models

# Create your models here.
class Ciudad(models.Model):
    nombre = models.CharField(max_length=50, unique=True)
    region = models.CharField(max_length=100, verbose_name="Región")
    
    def __str__(self):
        return self.nombre
    
class Categoria(models.Model):
    nombre = models.CharField(max_length=100)
    
    def __str__(self):
            return self.nombre
    
class Restaurante(models.Model):
    nombre = models.CharField(max_length=50, unique=True)
    descripcion = models.TextField()
    imagen = models.ImageField(upload_to="restaurantes") # Da error sin pillow
    ciudad = models.ForeignKey(Ciudad, on_delete=models.CASCADE)
    categoria = models.ManyToManyField(Categoria)
    
