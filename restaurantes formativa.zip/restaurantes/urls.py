from django.urls import path
from . import views

urlpatterns = [
    path("", views.restauranteListView, name='listar'),
    path("crear/", views.restauranteCreateView, name='crear'),
    path("actualizar/<int:id>/", views.restauranteUpdateView, name='actualizar'),
    path("detalle/<int:id>/", views.restauranteDetailView, name='detalle'),
]
